This is the companion video for the submission
an efficient acyclic contact planner for multiped robots.
